import React from "react";
const Home = () => {
  return (
    <div>
      <h1>This is mern App</h1>
      <i class="fa fa-xing" aria-hidden="true"></i>
    </div>
  );
};

export default Home;
